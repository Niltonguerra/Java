/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.atividade_tpi7;
import javax.swing.JOptionPane;
/**
 *
 * @author Nilton
 */
public class Atividade_TPI7 {

 public static void main(String[] args) {


 
        while(true)
    {
        String escolh=JOptionPane.showInputDialog("Que dia é hoje?");
        while(!escolh.matches("[0-9]*")){
            JOptionPane.showMessageDialog(null,"Digite apenas numero! ");
             escolh=JOptionPane.showInputDialog("Que dia é hoje?");
        }
        int diaa = Integer. parseInt(escolh);        

        escolh=JOptionPane.showInputDialog("Que mês é esse?");
        while(!escolh.matches("[0-9]*")){
            JOptionPane.showMessageDialog(null,"Digite apenas numero! ");
             escolh=JOptionPane.showInputDialog("Que mês é esse?");
        }
        int mess = Integer. parseInt(escolh);
   
        escolh=JOptionPane.showInputDialog("Que ano é esse?");    
        while(!escolh.matches("[0-9]*")){
            JOptionPane.showMessageDialog(null,"Digite apenas numero! ");
             escolh=JOptionPane.showInputDialog("Que ano é esse?");
        }
        int ano = Integer. parseInt(escolh);
        
        datas D = new datas();
        D.set_dia(diaa);
        D.set_mes(mess);
        D.set_ano(ano);

        JOptionPane.showMessageDialog(null,"Hoje é dia "+D.get_dia()+" do mês "+D.get_mes()+" do ano "+ D.get_ano()+ " ,ou seja,hoje é: "+D.displayData());

            }
    }
 }
