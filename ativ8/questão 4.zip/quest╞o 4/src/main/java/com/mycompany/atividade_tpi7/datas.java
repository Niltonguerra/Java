/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.atividade_tpi7;

/**
 *
 * @author Nilton
 */
public class datas {
int dia,mes,ano = 0;
    
   
     public void set_dia(int diaa){
        dia = diaa;
    }
    
    public void set_mes(int mess){
        mes = mess;
    }
    public void set_ano(int anoo){
        ano = anoo;
    }
    
    
    
    
    public int get_dia(){
        return dia;
    }
    
    public int get_mes(){
        return mes;
    }
    public int get_ano(){
        return ano;
    }
    
    public String  displayData(){
    String  data=  dia + "/" + mes + "/" + ano;
    return data; 
}
    

    
}
