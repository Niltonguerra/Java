/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.atividade_tpi7;
import javax.swing.JOptionPane;
/**
 *
 * @author Nilton
 */
public class calcul {
    double num1, num2,resul = 0;
    char simb;
    String resultado = "";
    
   
    public void calcula(double num1,char simb,double num2){
        switch (simb) {
            case '+':
                resul = num1+num2;
                break;
            case '-':
                resul = num1-num2;
                break;
            case '*':
                resul = num1*num2;
                break;
            case '/':
                if(0 == num2){
                    resultado = "não é possivel dividir por zero!";
                }
                resul = num1/num2;
                break;
            default:
                break;
        }
    }
    
      public String imprime_calculo(){
          if(num2 != 0){
       resultado = String.valueOf(resul);
        }
      return resultado;
        
    }
    
}
