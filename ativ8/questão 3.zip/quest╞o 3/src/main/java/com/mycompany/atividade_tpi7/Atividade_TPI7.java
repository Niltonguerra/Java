/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.atividade_tpi7;
import javax.swing.JOptionPane;
/**
 *
 * @author Nilton
 */
public class Atividade_TPI7 {

public static void main(String[] args) {
    double num1,num2 = 0;
    char simbolo;
    String esc;

 
        while(true)
    {

            esc=JOptionPane.showInputDialog("CALCULADORA!!\n\n digite o primeiro valor");
            while(!esc.matches("[0-9]*")){
            JOptionPane.showMessageDialog(null,"Digite apenas numero! ");
             esc=JOptionPane.showInputDialog("CALCULADORA!!\n\n digite o primeiro valor");
        }
        num1 = Double.parseDouble(esc);
        
           esc=JOptionPane.showInputDialog("CALCULADORA!!\n\n digite:\n '+' para somar \n '-' para  subtrair\n'*' para  multiplicar\n'/' para  dividir\n");    
        simbolo = esc.charAt(0);
        
            esc=JOptionPane.showInputDialog("CALCULADORA!!\n\n digite o segundo valor");
            while(!esc.matches("[0-9]*")){
            JOptionPane.showMessageDialog(null,"Digite apenas numero! ");
             esc=JOptionPane.showInputDialog("CALCULADORA!!\n\n digite o segundo valor");
        }
        num2 = Double.parseDouble(esc);

        calcul calculadoras = new calcul();
        calculadoras.calcula(num1, simbolo, num2);


        JOptionPane.showMessageDialog(null,"O resultado é:\n" + calculadoras.imprime_calculo());

            }
    }
 }
